from flask import Flask, redirect, render_template,request,session

contador= Flask (__name__)
contador.secret_key="contador"


@contador.route ("/")
def obtener_contador():
    if 'contador' in session:
        session['contador']+= 1
    else:
        session['contador']=1
    return render_template("index.html")

@contador.route("/", methods =['POST'])
def agregar_contador():
    return redirect("/")

@contador.route("/destroy_session", methods =['GET'])
def reiniciar_contador():
    session.clear()		
    session.pop('contador',0)	
    return redirect("/")


if __name__=="__main__":
    contador.run(debug=True)
